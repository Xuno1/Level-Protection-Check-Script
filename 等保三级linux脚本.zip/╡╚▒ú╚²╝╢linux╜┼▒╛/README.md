# shell-linux
运行方式 拖到linux主机
chmod +x test.sh
./test.sh
